# La Silent Aura Telegram ↔ WhatsApp Bridge

Render uses render.yaml to extract and run the prepared bridge archive.
