# La Silent Aura — Railway-ready Telegram ↔ WhatsApp Bridge

This package is prepared for Railway. It starts the bridge with `npm start` and exposes `/health`.

Required Railway variables:
- TELEGRAM_BOT_TOKEN
- WHATSAPP_PHONE_NUMBER
- WHATSAPP_GROUP_ID (optional on first run)
- TELEGRAM_CHAT_ID (optional; discovered from the first Telegram message)
- BRIDGE_MODE=both

For WhatsApp session persistence, attach a Railway volume mounted at `/data`.
